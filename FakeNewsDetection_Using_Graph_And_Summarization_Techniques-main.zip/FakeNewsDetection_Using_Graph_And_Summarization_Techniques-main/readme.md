# Fake News Detection Using Graph and Summarization Techniques
Each provided folder contains following things:
1.code.py
2.Eval.py

Please download GoogleNews-vectors-negative300.bin from below given link:
https://drive.google.com/file/d/0B7XkCwpI5KDYNlNUTTlSS21pQmM/edit

After successfull extraction place it along with above mentioned files



->Open code.py file and change dataset_name and model name pattern in which name format model is saved.
->Do the same for Eval.py file

Trained_model will store model results for each epoch 

